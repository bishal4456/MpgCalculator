package com.example.cartco4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_stats.*

class StatsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)

        showStats.text = "Totals over ${Model.list.size} fillups"
        editGallons.text = "%,.1f gallons".format(Model.getTotalGallons())
        editCost.text = "$%,.2f".format(Model.getTotalCost())
        showDistance.text = String.format("%.1f miles", Model.getDistance())
        showMpg.text = "%.1f MPG".format(Model.getMPG())
    }
}