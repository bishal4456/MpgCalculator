package com.example.cartco4

import com.example.cartco4.model.Item
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

object Model {

    val simpleDateFormat = SimpleDateFormat("MMMM dd, yyyy")
    val date = simpleDateFormat.format(Date())

    var posi = -1
    var dataChanged = false
    var list = ArrayList<Item>()

    fun reset() { list.clear() }

    fun getTotalGallons() : Double {
        var sum = 0.0
        for (item in list) sum += item.gallons
        return sum
    }

    fun getFirstFillup() : Double {
        if (list.size == 0)
            return 0.0
        else
            return list[0].gallons
    }

    fun getStartOdo() = if (list.size == 0) 0.0 else list[0].odo

    fun getCurrentOdo() : Double {
        if (list.size == 0)
            return 0.0
        else
            return list[list.size-1].odo
    }

    fun getTotalCost() : Double {
        var sum = 0.0
        for (item in list)
            sum += item.cost

        return sum
    }

    fun getDistance() = getCurrentOdo() - getStartOdo()

    fun getMPG() : Double {
        if (list.size <= 1)
            return 0.0
        else {
            return getDistance() / (getTotalGallons() - getFirstFillup())
        }
    }
}