package com.example.cartco4.model

data class Item (var date: String, var gallons: Double, var odo : Double, var cost: Double)




