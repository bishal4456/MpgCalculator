package com.example.cartco4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.cartco4.model.Item
import kotlinx.android.synthetic.main.activity_add.*

class AddActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        buttonAdd.setOnClickListener {

            Model.list.add(
                    Item(
                        Model.date, textGallons.text.toString().toDouble(),
                        textMiles.text.toString().toDouble(), textCost.text.toString().toDouble()
                    )
                )

                Model.dataChanged = true
                finish()
        }
    }
}
