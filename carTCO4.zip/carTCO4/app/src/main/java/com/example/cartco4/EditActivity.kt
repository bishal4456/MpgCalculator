package com.example.cartco4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.cartco4.model.Item
import kotlinx.android.synthetic.main.activity_edit.*

class EditActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        if (Model.posi>=0){
            editGallons.setText(Model.list[Model.posi].gallons.toString())
            editMiles.setText(Model.list[Model.posi].odo.toString())
            editCost.setText(Model.list[Model.posi].cost.toString())
        }

        buttonSave.setOnClickListener {

            Model.list.set(Model.posi,
                Item(
                    Model.date, editGallons.text.toString().toDouble(),
                    editMiles.text.toString().toDouble(), editCost.text.toString().toDouble()
                )
            )
            Model.dataChanged = true
            finish()
        }
    }
}
