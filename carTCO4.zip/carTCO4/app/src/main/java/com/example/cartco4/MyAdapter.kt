package com.example.cartco4

import android.content.Intent
import android.view.*
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.cartco4.model.Item

class MyAdapter(private val myDataset: MutableList<Item>) :
    RecyclerView.Adapter<MyAdapter.MyViewHolder>() {

    val here = this

    inner class MyViewHolder(val cardView: CardView) : RecyclerView.ViewHolder(cardView),
        MenuItem.OnMenuItemClickListener, View.OnCreateContextMenuListener
        {
            override fun onMenuItemClick(item: MenuItem?): Boolean {

                var pos = adapterPosition
                Model.list.removeAt(pos)
                here.notifyDataSetChanged()
                return true
            }

            override fun onCreateContextMenu(
                menu: ContextMenu?,
                v: View?,
                menuInfo: ContextMenu.ContextMenuInfo?
            )
            {
                var menuItem = menu?.add("Delete")
                menuItem?.setOnMenuItemClickListener (this)
            }
            init {
                itemView.setOnCreateContextMenuListener(this)
            }
            val textCard1 = itemView.findViewById<TextView>(R.id.displayMiles)
            val textCard2 = itemView.findViewById<TextView>(R.id.displayDollars)
            val textCard3 = itemView.findViewById<TextView>(R.id.displayDate)
            val textCard4 = itemView.findViewById<TextView>(R.id.displayGallons)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAdapter.MyViewHolder {
        val aCardView = LayoutInflater.from(parent.context).inflate(
            R.layout.card_one,
            parent,
            false
        ) as CardView
        return MyViewHolder(aCardView)
    }

    override fun getItemCount() = myDataset.size

    override fun onBindViewHolder(holder: MyViewHolder, position: Int)  {
        holder.itemView.setOnClickListener {
            Model.posi = position
            var intent = Intent(holder.itemView.context,EditActivity::class.java)
            holder.itemView.context.startActivity(intent)
        }

        holder.textCard1.text = myDataset[position].odo.toString()+ " miles"
        holder.textCard2.text = "$"+ myDataset[position].cost.toString()
        holder.textCard3.text = Model.date
        holder.textCard4.text = myDataset[position].gallons.toString()+ " gallons"
    }
}




